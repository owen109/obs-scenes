var socket
var amount

function setup() {
	socket = io.connect()
	socket.on("connected", connection)
	socket.on("updateScenes", connection)
}

async function connection(data) {
	document.getElementById("sceneButtons").innerHTML = ''
	amount = data.length
	for (let i = 0; i < data.length; i++) {
		console.log(data[i])
		document.getElementById("sceneButtons").innerHTML += 
		`<div class="item "id="${data[i]}"><h1 class="tt">${data[i]}</h1></a>`
	}
	data.forEach(scene => {
		document.getElementById(scene).addEventListener('click', () => {
			socket.emit("SwitchScene", scene)
		});
	});
}
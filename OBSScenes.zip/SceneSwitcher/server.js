const socket = require('socket.io')
const express = require('express')
const colors = require('colors')
const OBSWebSocket = require('obs-websocket-js')
const events = require("events")
const path = require("path")

//arg order, (clientPort'2', obsPort'3', obsPassword'4')

const PORT = (() => {if(process.argv[2] != null){return process.argv[2]} else {return 12346}})() 
const OBSPORT = (() => {if(process.argv[3] != null){return process.argv[3]} else {return 4444}})()
const OBSPASSWORD = (() => {if(process.argv[4] != null){return process.argv[4]} else {return null}})()
console.log(process.argv[1])
console.log(`Connecting to OBS on port: ${OBSPORT}\nAuthenticating with a password of: ${OBSPASSWORD}\nConnect the client on: http://10.0.1.13:${PORT}`.green)

var app = express()
var server = app.listen(PORT)

app.use(express.static(path.resolve(__dirname, "public")))
io = socket(server)

const obs = new OBSWebSocket();
var scenes = [];
var currentScene;
var eventEmitter = new events.EventEmitter()
async function obsStuff() {
	obs.connect({
		address: `localhost:${OBSPORT}`,
		password: OBSPASSWORD
	}).then(() => {
		obs.on('SwitchScenes', data => {
			currentScene = data.sceneName;
			console.log(`New Active Scene: ${data.sceneName}`);
		})
		eventEmitter.on("updateSceneList", () => {
			obs.send("GetSceneList").then((data) => {
				data.scenes.map(scene => {
					scenes.push(scene.name);

				})
			}).then(() => eventEmitter.emit("updateUI"))
		})
	}).catch(err => {
		console.log(err)
	})

	obs.on('error', err => {
		console.error('socket error:', err);
	});
}
async function switchObsScene(scene) {
	if (currentScene != scene) {
		obs.connect({
			address: `localhost:${OBSPORT}`,
			password: '4422'
		}).then(() => {
			obs.send("SetCurrentScene", {
				'scene-name': scene
			}).catch(err => {
				console.log(err)
			});

		}).catch(err => {
			console.log(err)
		})
		obs.on('error', err => {
			console.error('socket error:', err);
		});
	}
}
obsStuff().then(() => {
	io.sockets.on("connection", (socket) => {
		console.log(`connected to: ${socket.id} on port: ${PORT}`.green)
		socket.emit("connected", scenes)
		socket.on("SwitchScene", switchObsScene)
		eventEmitter.on("updateUI", () => {
			socket.emit("updateScenes", scenes);
		})
	})
}).then(() => {
	setInterval(() => {
		scenes = [];
		eventEmitter.emit("updateSceneList")
	}, 1000)
}).catch(err => {
	console.log(err)
})
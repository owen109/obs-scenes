var socket
var amount

function setup() {
	socket = io.connect()
	socket.on("connected", connection)
	socket.on("updateScenes", connection)
}

function connection(data) {
	document.getElementById("sceneButtons").innerHTML = ''
	amount = data.length
	for (let i = 0; i < data.length; i++) {
		console.log(data[i])
		document.getElementById("sceneButtons").innerHTML +=
        `<a href="#" id="${data[i]}" class="button w-button" style="transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1) 
         rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg, 0deg); transform-style: preserve-3d;">${data[i]}</a>       `
	}
	data.forEach(scene => {
		document.querySelector(`[id="${scene}"]`).addEventListener('click', () => {
			socket.emit("SwitchScene", scene)
		});
	});
}